import java.util.*;
class calculatormain{
	public static void main(String args[]){
		calculator c=new calculator();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter two values");
		c.a=sc.nextInt();
		c.b=sc.nextInt();
		System.out.println("enter num to perform operation");
		System.out.println("1.add\n2.sub\n3.mul\n4.div\n");
		int opt=sc.nextInt();
		switch(opt){
			case 1:
				c.add();
				break;
			case 2:
				c.sub();
				break;
			case 3:
				c.mul();
				break;
			case 4:
				c.div();
				break;
			default:
				System.out.println("invalid option");
				break;
			}
		}
	}
				
