public class primefactors{
	void primefact(int n){
		int i,j;
		for(i=2;i<n;i++){
			if(n%i==0){
				//int j=1;
				for(j=2;j<=i;j++){
					if(i%j==0){
						break;
					}
					}
			if(i==j){
				System.out.println(i);
						}
				}
			}
			}
		}	
