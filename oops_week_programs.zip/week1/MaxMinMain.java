import java.util.*;
class MaxMinMain{
	public static void main(String args[]){
	int i;
		Scanner s=new Scanner(System.in);
		MaxMin m=new MaxMin();
		System.out.println("enter the no.of elemnts");
		m.n=s.nextInt();
		System.out.println("enter elemnts");
		for(i=0;i<m.n;i++){
			m.a[i]=s.nextInt();
			}
		m.max();
		m.min();
	}
}
