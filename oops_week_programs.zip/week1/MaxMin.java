public class MaxMin{
	int n,i,max=-10000,min=10000;
	int a[]=new int[10];
	void max(){
	for(i=0;i<n;i++){
	if(a[i]>max){
		max=a[i];
	}
	}
	System.out.println("max value:"+max);
	}
	void min(){
	for(i=0;i<n;i++){
		if(a[i]<min){
		min=a[i];
		}
	}
	System.out.println("min value:"+min);
	}
}
	
	
