public class calculator{
	int a,b;
	 void add(){
		System.out.println("addition:"+(a+b));
	}
	void sub(){
		System.out.println("subtraction:"+(a-b));
	}
	void mul(){
		System.out.println("multiplication:"+(a*b));
		}
	void div(){
		System.out.println("division:"+(a/b));
		}
	/*void mod(){
		System.out.println(a%b);
	}*/
}
