import java.util.*;
class primefactorsmain{
	public static void main(String args[]){
		primefactors p=new primefactors();
		Scanner s=new Scanner(System.in);
		System.out.println("enter any number");
		int n=s.nextInt();
		p.primefact(n);
		}
	}
