class hellomain{
	public static void main(String args[]){
	hello h=new hello();
		h.print();
		}
		}
		
