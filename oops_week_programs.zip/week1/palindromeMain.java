import java.util.*;
public class palindromeMain{
	public static void main(String args[]){
	int n;
	Scanner s=new Scanner(System.in);
	palindrome1 p=new palindrome1();
	System.out.println("enter number ");
	n=s.nextInt();
	p.palin(n);
	}
}
