class palindrome1{
	void palin(int n){
	int m=n;
	int r,rev=0;
		while(n>0){
			r=n%10;
			n=n/10;
			rev=rev*10+r;
			}
		if(rev==m){
			System.out.println("palindrome");
		}
		else{
			System.out.println("not palindrome");
		}
	}
}
