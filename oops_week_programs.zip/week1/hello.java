public class hello{
	void print(){
		System.out.println("hello world");
	}
	}
