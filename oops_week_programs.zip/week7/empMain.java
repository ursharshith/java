import java.util.Scanner;
class empMain{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		weeklyemployed w=new weeklyemployed();
		System.out.println("enter amount for 1 week");
		w.amount=sc.nextDouble();
		
		System.out.println("enter no.of weeks");
		w.weeks=sc.nextInt();
		
		hourlyemployed h=new hourlyemployed();
		System.out.println("enter amount for 1 hour");
		h.amount=sc.nextDouble();
		
		System.out.println("enter no.of hours");
		h.hours=sc.nextInt();
		
		System.out.println("total amount to be paid for weekly emp:"+ w.getamount());
		System.out.println("total amount to be paid for hourly emp:"+h.getamount());
}
}
