/*
 * Create an abstract class Employee with methods getAmount() which displays the amount paid to employee. 
Reuse this class to calculate the amount to be paid to WeeklyEmployeed and HourlyEmployee according to no. 
of hours and total hours for HourlyEmployee and no. of weeks and total weeks for WeeklyEmployee.
 */


 class main_2{
    public static void main(String[] args){
        
    }
 }