/*
 * Create an abstract class Shape which calculate the area and volume of 2-d and 3-d shapes with methods 
getArea() and getVolume(). Reuse this class to calculate the area and volume of square ,circle ,cube and 
sphere.
 */
import java.util.*;
class main_1{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        cube c=new cube();
        circle ci=new circle();
        sphere sp=new sphere();
        square sq=new square();
        do{
            System.out.println("Choose one option: ");
            System.out.println("1.Cube\n2.Circle\n3.Sphere\n4.Square\n5.Exit");
            int k=s.nextInt();
            switch(k){
                case 1: c.read();
                        c.getVolume();
                        break;
                case 2:ci.read();
                        ci.getArea();
                        break;
                case 3:sp.read();
                        sp.getVolume();
                        break;
                case 4:sq.read();
                        sq.getArea();
                        break;
                case 5:System.out.println("Exiting");
                        System.exit(0);
                default:
                        System.out.println("Choose valid option");
                        break;
            }
        }while(true);
    }
}

