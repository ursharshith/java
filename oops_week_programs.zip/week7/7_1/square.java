import java.util.*;
class square extends shape{
    private double side;
    void setSide(double s){
        side=s;
    }
    double getSide(){
        return side;
    }
    void getArea(){
        System.out.println("Arae of square: "+side*side);
    }
    void getVolume(){}
    void read(){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter side: ");
        setSide(s.nextDouble());
    }
}
