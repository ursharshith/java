import java.util.*;
class cube extends shape {
    private double side;
    void setSide(double s){
        side=s;
    }
    double getSide(){
        return side;
    }
    void getArea(){}
    void getVolume(){
        System.out.println("Volume of cube "+side*side*side);
    }
    void read(){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter side: ");
        setSide(s.nextDouble());
    }
}
