import java.util.*;
class sphere extends shape{
    private double radius;
    void setRadius(double r){
        radius=r;
    }
    double getRadius(){
        return radius;
    }
    void getArea(){}
    void getVolume(){
        System.out.println("Volume of sphere: "+(4/3)*Math.PI*radius*radius*radius);
    }
    void read(){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter radius: ");
        setRadius(s.nextDouble());
    }
}
