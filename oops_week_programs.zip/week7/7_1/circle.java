import java.util.*;
class circle extends shape{
    private double radius;
    void setRadius(double r){
        radius=r;
    }
    double getRadius(){
        return radius;
    }
    void getArea(){
        System.out.println("Area of circle: "+Math.PI*radius*radius);
    }
    void getVolume(){}
    void read(){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter radius: ");
        setRadius(s.nextDouble());
    }
}
