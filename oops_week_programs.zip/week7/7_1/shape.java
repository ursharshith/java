

abstract class shape {
    abstract void getArea();
    abstract void getVolume();   
}
