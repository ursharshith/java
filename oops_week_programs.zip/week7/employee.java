abstract class employee{
	abstract double getamount();
}
class weeklyemployed extends employee{
	double amount;
	int weeks;
	double getamount(){
		return weeks*amount;
	}
}
class hourlyemployed extends employee{
	double amount;
	int hours;
	double getamount(){
		return hours*amount;
	}
}
