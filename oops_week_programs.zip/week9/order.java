class order{
public static void main(String args[]){
	try{
		int a=2;
		int b=0;
		int res=a/b;
		System.out.println(res);
	}
	catch(Exception e){
		System.out.println(e);
	}
	catch (ArithmeticException e){
		System.out.println(e);
	}
	
	
	}
}
	
	
