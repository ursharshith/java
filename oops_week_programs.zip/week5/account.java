import java.util.*;
class account{
      double acc_bal;
	public account(double acc_bal){
		this.acc_bal=acc_bal;
	}
	void credit(double a){
	//void credit(double a){
		acc_bal=acc_bal+a;
		System.out.println("acc bal after credited: "+(acc_bal));
	}
	void debit(double b)
	//void debit(double b)
	{
		if(acc_bal>b){
			acc_bal=acc_bal-b;
			System.out.println("bal after debited: "+acc_bal);
		}
		else{
			System.out.println("Debit amount exceeded account balance");
		}
	}
	void getbalance(){
	System.out.println("total balance: "+acc_bal);	
	
}
}
