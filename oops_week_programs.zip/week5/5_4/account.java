import java.util.*;
class account{
    private double acc_bal;
    String acc_name,acc_no,acc_address;
    void setAcc_bal(double acc_bal){
        //this.acc_bal=(acc_bal>0.0)?acc_bal:System.out.println("Balance can't be zero or negative");
        if(acc_bal>0){
            this.acc_bal=acc_bal;
        }
        else
            System.out.println("Balance can't be zero or negative");
    }
    public account(double acc_bal){
        setAcc_bal(acc_bal);
    }
    public void credit(double amount){
        acc_bal=acc_bal+amount;
        System.out.println("Amount of "+amount+" is credited");
    }
    public double getAcc_bal(){
        return acc_bal;
    }
    public void debit(double amount){
        if(amount<acc_bal){
            acc_bal=acc_bal-amount;
            System.out.println("Amount of "+amount+" is debited");
        }
        else    
            System.out.println("Debit amount exceeded account balance");
    }
    void print(){
        Scanner s=new Scanner(System.in);
        int k;
        double am;
        do{ 
            System.out.println("Choose one option: ");
            System.out.println("1.View balance\n2.Credit Amount\n3.Debit Amount\n4.Exit");
            k=s.nextInt();
            switch(k){
                case 1:System.out.println("Balance is: "+getAcc_bal());
                    break;
                case 2:
                    System.out.println("Enter amount to credit: ");
                    am=s.nextDouble();
                    credit(am);
                   // System.out.println(am+" amount is credited");
                    //System.out.println("Balance after credit is: "+getAcc_bal());
                    break;
                case 3:
                    System.out.println("Enter amount to debit: ");
                    am=s.nextDouble();
                    debit(am);
                 //   System.out.println(am+" amount is debited");
                  //  System.out.println("Balance after debit is: "+getAcc_bal());
                    break;
                case 4:System.out.println("Exiting...");
                    System.exit(0);
                 default:
                    System.out.println("choose valid option:(");
                    break;
            }

        }while(true);
    }

}
