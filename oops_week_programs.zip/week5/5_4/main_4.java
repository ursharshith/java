import java.util.*;

class main_4{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        double bal=s.nextDouble();
        account a=new account(bal);
        /*double am=s.nextDouble();
        System.out.println(a.getAcc_bal());
        a.credit(am);
        System.out.println(a.getAcc_bal());
        a.debit(am);
        System.out.println(a.getAcc_bal());*/
        a.print();
    }
}
