import java.util.*;
class AccMain{
	public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	//static double acc_bal; 
	System.out.println("enter account details");
	System.out.println("------------------------");
	System.out.println("enter account number");
	int acc_num=sc.nextInt();
	System.out.println("enter account name");
	String acc_name=sc.next();
	System.out.println("enter account address");
	String acc_address=sc.next();
	System.out.println("enter account balance");
	double acc_bal=sc.nextDouble();
	account ac=new account(acc_bal);
	
	//ac.account(acc_bal);
	System.out.println("1.credit\n2.debit\n3.getbalance\n4.exit");
	
	while(true)
	{
	System.out.println("enter any option");
	int ch=sc.nextInt();
	switch(ch){
		case 1:
			System.out.println("enter amount to credit");
			double a=sc.nextDouble();
			ac.credit(a);
			break;
		case 2:
			System.out.println("enter amount to debit");
			double b=sc.nextDouble();
			ac.debit(b);
			break;
		case 3:
			ac.getbalance();
			break;
		case 4:
			System.exit(0);
			break;
		}
	}
	}
}
