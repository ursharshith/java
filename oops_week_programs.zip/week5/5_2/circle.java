import java.util.*;

class circle{
    private double rad;
    void setRad(double rad){
        this.rad=rad;
    }
    double circleArea(){
        return Math.PI*rad*rad;
    }
    double circlePerimeter(){
        return Math.PI*2*rad;
    }
}
