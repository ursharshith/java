import java.util.*;

class main_2{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        circle c=new circle();
        c.setRad(s.nextDouble());
        System.out.println("Area is: "+c.circleArea());
        System.out.println("Perimeter is: "+c.circlePerimeter());
    }
}
