class overload{	

	void area(double side){
		System.out.println("area of square is: "+side*side);
	}
	void area(double base,double height){
		System.out.println("area of triangle is: "+(0.5)*height*base);
	}
	void area(double length,float breadth){
		System.out.println("area of rectangle is: "+length*breadth);
	}
	void area(float radius){
		 System.out.println("area of circle is: "+Math.PI*radius*radius);
	}
}
