class employee{
	String firstname;
	String lastname;
	void setfirstname(String firstname){
		this.firstname=firstname;
	}
	void setlastname(String lastname){
		this.lastname=lastname;
	}
	String getfirstname(){
		return firstname;
	}
	String getlastname(){
		return lastname;
	}
}
class ContractEmployee extends employee{
	String department;
	String designation;
	int salary;
	String displayfullname(){
		 return super.getfirstname()+" "+super.getlastname();
      		 
	}
	void setdepartment(String department){
		this.department=department;
	}
	String getdepartment(){
		return department;
	}
	void setdesignation(String designation){
		this.designation=designation;
	}
	String getdesignation(){
		return designation;
	}
	int sal(){
		return salary;
	}
}
class RegularEmployee extends employee{
	String department;
	String designation;
	int salary;
	String displayfullname(){
		return super.getfirstname()+" "+super.getlastname();
	}
	void setdepartment(String department){
		this.department=department;
	}
	String getdepartment(){
		return department;
	}
	void setdesignation(String designation){
		this.designation=designation;
	}
	String getdesignation(){
		return designation;
	}
	int sal(){
		return salary;
	}
}

