import java.util.*;
class vehiclemain{
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	vehicle v=new vehicle();
	TwoWheeler t=new TwoWheeler();
	FourWheeler f=new FourWheeler();
	
	System.out.println("enter vehicle number");
	v.setvehicle_num(sc.next());
	System.out.println("enter color");
	v.setcolor(sc.next());
	System.out.println("enter insurance number");
	v.setinsurance_num(sc.nextInt());
	System.out.println("enter consumption");
	v.setconsumption(sc.nextInt());
	System.out.println("enter maintanence of two wheeler");
	t.setmaintanence(sc.nextInt());
	System.out.println("enter average of 2wheeler");
	t.setavg(sc.nextFloat());
	System.out.println("enter maintanence of  4wheeler");
	f.setmaintanence(sc.nextInt());
	System.out.println("enter average of 4wheeler");
	f.setavg(sc.nextFloat());
	System.out.println();
	v.displayconsumption();
	t.print();
	f.print();
	}
}
	
