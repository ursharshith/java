class poly{
	double radius;
	double height,length,breadth;
	double base;
	double area(){    //this area(super class) will be overridded coz same methods will be there in subclasses,this is called overriding
		return 0.5*base*height;
		}
	}
class rectArea extends poly{
	double area(){
		return length*breadth;
	}
}
class circleArea extends poly{
	double area(){
		return Math.PI*radius*radius;
	}
}
	
		
		
