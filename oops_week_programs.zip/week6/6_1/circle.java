import java.util.*;

class circle extends shapes{
    private double radius;
    void setRadius(double r){
        radius=(r>0)?r:1;    // if radius entered is 0 or negative then take r=1
    }
    double getRadius(){
        return radius;
    }
    void dimensions(){
        System.out.println("Dimensions involved: ");
        System.out.println("Radius--> "+getRadius());
    }
    double area(){
        return Math.PI*radius*radius;
    }
    double perimeter(){
        return 2*Math.PI*radius;
    }
    void read(){
        Scanner s=new Scanner(System.in);
        setRadius(s.nextDouble());
    }
    void print(){
        dimensions();
        System.out.println("Area of circle: "+area());
        System.out.println("Perimeter of circle: "+perimeter());
    }
}
