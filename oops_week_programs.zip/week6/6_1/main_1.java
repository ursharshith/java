import java.util.Scanner;

class main_1 {
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        rectangle r=new rectangle();
        circle c=new circle();
      
        do{
            System.out.println("Choose one option: ");
            System.out.println("1.Read circle details\n2.Read rectangle details\n3.Print circle details\n4.Print rectangle details\n5.Exit\n");
            int k=s.nextInt();
            switch(k){
                case 1: c.read();
                    break;
                case 2:r.read();
                    break;
                case 3:c.print();
                    break;
                case 4:r.print();
                    break;
                case 5:System.out.println("Exiting......");
                    System.exit(0);
                default:System.out.println("Youuuuuu waste fellow choose valid option >..<");
                    break;
            }
        }while(true);
    }
}
