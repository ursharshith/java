import java.util.*;
class rectangle extends shapes{
    private double length,breadth;

    void setLength(double l){
        length=(l>0)?l:1;
    }
    void setBreadth(double b){
        breadth=(b>0)?b:1;
    }
    double getLength(){
        return length;
    }
    double getBreadth(){
        return breadth;
    }
    void dimensions(){
        System.out.println("Dimensions involved: ");
        System.out.println("Length--> "+getLength()+"\n"+"Breadth--> "+getBreadth());
    }
    double area(){
        return length*breadth;
    }
    double perimeter(){
        return 2*(length+breadth);
    }
    void read(){
        Scanner s=new Scanner(System.in);
        setLength(s.nextDouble());
        setBreadth(s.nextDouble());
    }
    void print(){
        dimensions();
        System.out.println("Area of Rectangle: "+area());
        System.out.println("Perimeter of rectangle: "+perimeter());
    }
}