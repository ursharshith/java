abstract class shapes{
    abstract void dimensions();
    abstract double area();
    abstract double perimeter();
}
