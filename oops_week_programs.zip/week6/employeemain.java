import java.util.*;
class employeemain{
	public static void main(String args[]){
		employee e=new employee();
		ContractEmployee c= new ContractEmployee();
		RegularEmployee r=new RegularEmployee();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter contract first name");
		c.firstname=sc.next();
		
		System.out.println("enter contract last name");
		c.lastname=sc.next();
		
		System.out.println("enter regular employee first name");
		r.firstname=sc.next();
		
		System.out.println("enter regular employee last name");
		r.lastname=sc.next();
		
		System.out.println("enter regular emp department");
		r.setdepartment(sc.next());
		
		System.out.println("enter regular emp designation");
		r.setdesignation(sc.next());
		
		System.out.println("enter contract department");
		c.setdepartment(sc.next());
		
		System.out.println("enter contract designation");
		c.setdesignation(sc.next());
		
		System.out.println("enter contract emp salary");
		c.salary=sc.nextInt();
		
		System.out.println("enter regular emp emp salary");
		r.salary=sc.nextInt();
		
		System.out.println("\ncontract emp details\n----------------------\nemp name: "+c.displayfullname()+"\ndept: "+c.getdepartment()+"\ndesignation: "+c.getdesignation()+"\nsalary: "+c.sal());
		System.out.println("\nregular emp details\n------------------------\nemp name :"+r.displayfullname()+"\ndept: "+r.getdepartment()+"\ndesignation: "+r.getdesignation()+"\nsalary: "+r.sal());
}
}
		
