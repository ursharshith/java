class NonGeared extends twowheeler{
    //private double avg;
  /*   void setAvg(double avg){
        this.avg=avg;
    }
    double getAvg(){
        return avg;
    }*/
    void printavg(){
        System.out.println("2 wheeler non geared avg is: "+getAvg());
    }
}