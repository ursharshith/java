/*
 * Extend the above TwoWheeler class with methods getType() and getName() which gives the information 
about the type and the name of the company.Create sub-classes Geared and NonGeared with method average() 
to print the average of a geared and non-geared two wheeler.
 */
import java.util.*;
class main_6{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        Geared g=new Geared();
        NonGeared ng=new NonGeared();
        g.setAvg(s.nextDouble());
        ng.setAvg(s.nextDouble());
        g.printavg();
        ng.printavg();
    }
}

