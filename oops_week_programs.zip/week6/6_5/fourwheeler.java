import java.util.*;

class fourwheeler extends vehicle{
    private double maintenance,avg;
    void setMaintenance(int mt){
        maintenance=mt;
    }
    void setAvg(double avg){
        this.avg=avg;
    }
    double getAvg(){
        return avg;
    }
    void setMaintenance(double m){
        maintenance=m;
    }
    double getMaintenance(){
        return maintenance;
    }
    void read(){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter four wheeler details: ");
        System.out.println("Enter vehicle_no: ");
        setVehicle_no(s.nextLine());
        s.nextLine();
        System.out.println("Enter brand: ");
        setBrand(s.next());
        System.out.println("Enter color required: ");
        setColor(s.next());
        System.out.println("Enter insurance no: ");
        setInsurance_no(s.nextInt());
        System.out.println("Enter consumption: ");
        setConsumption(s.nextInt());
        System.out.println("Enter average: ");
        setAvg(s.nextDouble());
        System.out.println("Enter maintenance: ");
        setMaintenance(s.nextDouble());
    }
    void print(){
        System.out.println("four wheeler details: ");
        System.out.println("Vehicle_no: "+getVehicle_no());
        System.out.println("Brand: "+getBrand());
        System.out.println("Color: "+getColor());
        System.out.println("Insurance_no: "+getInsurance_no());
        System.out.println("Consumption: "+getConsumption());
        System.out.println("Average: "+getAvg());
        System.out.println("Maintenanace: "+getMaintenance());
    }
}

