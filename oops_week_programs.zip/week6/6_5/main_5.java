import java.util.*;
/*
 * Write an application to create a super class Vehicle with information vehicle number,insurance number,color 
and methods getConsumption() displayConsumption(). Derive the sub-classes TwoWheeler and FourWheeler 
with method maintenance() and average() to print the maintenance And average of vehicle
 */
class main_5 {
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        twowheeler t=new twowheeler();
        fourwheeler f=new fourwheeler();
       //t.read();
       // t.print();
        do{
            System.out.println("Choose on option: ");
            System.out.println("1.Read two wheeler details\n2.Read four wheeler details\n3.Print two wheeler details\n4.Print four wheeler details\n5.Exit");
            int k=s.nextInt();
            switch(k){
                case 1:t.read();
                        break;
                case 2:f.read();
                        break;
                case 3:t.print();
                        break;
                case 4:f.print();
                        break;
                case 5:System.out.println("Exiting");
                        System.exit(0);
                default:
                        System.out.println("Choose valid option");
                        break;
            }
        }while(true);
    }
}

