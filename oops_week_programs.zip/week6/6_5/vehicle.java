


class vehicle{
    private String vehicle_no,brand,color;
    private int insurance_no,consumption;
    void setVehicle_no(String no){
        vehicle_no=no;
    }
    void setColor(String color){
        this.color=color;
    }
    void setInsurance_no(int in){
        insurance_no=in;
    }
    String getVehicle_no(){
        return vehicle_no;
    }
    String getColor(){
        return color;
    }
    int getInsurance_no(){
        return insurance_no;
    }
    void setConsumption(int l){
        consumption=l;
    }
    int getConsumption(){
        return consumption;
    }
    String getBrand(){
        return brand;
    }
    void setBrand(String b){
        brand=b;
    }
    void displayConsumption(){
        System.out.println("consumption: "+getConsumption());
    }
    
}