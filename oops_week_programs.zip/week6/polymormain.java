import java.util.*;
class polymormain{
	public static void main(String args[]){
		//polymor p=new polymor();
		rect r=new rect();
		square s=new square();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter side");
		s.side=sc.nextDouble();
		
		System.out.println("enter length");
		r.length=sc.nextDouble();
		
		System.out.println("enter breadth");
		r.breadth=sc.nextDouble();
		
		System.out.println("area of rectangle"+ r.area());
		System.out.println("area of square"+ s.area());
		
		}
	}
		
