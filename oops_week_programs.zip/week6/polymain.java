import java.util.*;
class polymain{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		poly p=new poly();
		rectArea r=new rectArea();
		circleArea c=new circleArea();
		System.out.println("enter height");
		p.height=sc.nextDouble();
		System.out.println("enter base");
		p.base=sc.nextDouble();
		System.out.println("enter length");
		r.length=sc.nextDouble();
		System.out.println("enter breadth");
		r.breadth=sc.nextDouble();
		System.out.println("enter radius");
		c.radius=sc.nextDouble();
		System.out.println(r.area());
		System.out.println(c.area());
		}
	}
		
