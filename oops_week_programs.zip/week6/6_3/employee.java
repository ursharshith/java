
//import java.util.Scanner;
class employee{
    private String firstname,lastname,Emp_id;
    private double salary;
    private int Emp_age;
    String first,last;
    String getFirstname(){
        return firstname;
    }
    String getLastname(){
        return lastname;
    }
    String getEmp_id(){
        return Emp_id;
    }
    
    void setEmp_id(String id){
        Emp_id=id;
    }
    int getEmp_age(){
        return Emp_age;
    }
    void setEmp_age(int age){
        Emp_age=age;
    }
    double getSalary(){
        return salary;
    }
    void setFirstname(String first){
        firstname=first;
    }
    void setLastname(String last){
        lastname=last;
    }
    
    void setSalary(double sal){
        salary=sal;
    }
    /*void read(){
        Scanner s=new Scanner(System.in);
        setFirstname(s.next());
        setLastname(s.next());

    }*/
}
