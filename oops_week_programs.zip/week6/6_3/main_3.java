
import java.util.*;
class main_3 {
    public static void main(String args[]){
        //employee e=new employee();
        Scanner s=new Scanner(System.in);
        contractEmployee ce=new contractEmployee();
        regularEmployee re=new regularEmployee();
        do{
            System.out.println("\n");
            System.out.println("Choose one option: ");
            System.out.println("1.Read Contract Employee Details\n2.Read Regular employee details\n3.Print Contract employee Details\n4.Print regular employee details\n5.exit");
            int n=s.nextInt();
            switch(n){

                case 1: System.out.println("Contract Employee Details: ");
                    ce.read();
                    break;
                case 2: System.out.println("Enter regular employee details: ");
                    re.read();
                    break;
                case 3:
                        System.out.println("\n\n");
                        ce.print();
                        break;
                case 4:
                        System.out.println("\n\n");
                        re.print();
                        break;
                case 5:
                        System.out.println("Exiting...");
                        System.exit(0);
                default:
                        System.out.println("Choose valid option :(");
                        break;
            }
        }while(true);
        
        //write switch case for reading and printing of respective employees-->case1 read contract emp details  case2 print ce details case3 read re details case 4 print re details

       /*  System.out.println("Enter desig: ");
        ce.setDesig(s.nextLine());
        s.nextLine();
        System.out.println("Enter firstname: ");
        ce.setFirstname(s.next());
        System.out.println("Enter lastname: ");
        ce.setLastname(s.next());
        System.out.println(ce.getdisplayfullname());
        System.out.println(ce.getDesig());
        */
    }
}
