import java.util.*;
public class contractEmployee extends employee{
    private String dept;
    private int wdays;
    String desig;
    int getWdays(){
        return wdays;
    }
    void setWdays(int num){
        wdays=num;
    }
    String getDesig(){
        return desig;
    }
    void setDesig(String des){
        desig=des;
    }
    String getDept(){
        return dept;
    }

    void setDept(String dept){
        this.dept=dept;
    }
    String getdisplayfullname(){
        //System.out.println("")
       // System.out.println(super.getFirstname()+" "+super.getLastname());
       String name=super.getFirstname()+" "+super.getLastname();
       return name;
    }
    void read(){
        Scanner s=new Scanner(System.in);
       
        System.out.println("Enter id: ");
        setEmp_id(s.next());
        System.out.println("Enter first name: ");
        setFirstname(s.next());
        System.out.println("Enter last name: ");
        setLastname(s.next());
        System.out.println("Enter age: ");
        setEmp_age(s.nextInt());
        System.out.println("Enter salary: ");
        setSalary(s.nextDouble());
        System.out.println("Enter desig: ");
        setDesig(s.next());
        s.nextLine();
        System.out.println("Enter department: ");
        setDept(s.nextLine());
        s.nextLine();
    }   
    void print(){
       // System.out.println(desig);
       System.out.println("Contract Employee Details: ");
        System.out.println("Id: "+getEmp_id());
        System.out.println("Full name: "+getdisplayfullname());
        System.out.println("Age: "+getEmp_age());
        System.out.println("Designation: "+getDesig());
        System.out.println("Department: "+getDept());
        System.out.println("Salary: "+getSalary());
    }

}
