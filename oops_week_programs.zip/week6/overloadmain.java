import java.util.*;
class overloadmain{
	public static void main(String args[]){
		double length,base,height,side;
		float radius,breadth;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter radius");
		radius=sc.nextFloat();
		
		System.out.println("enter base");
		base=sc.nextDouble();
		
		System.out.println("enter height");
		height=sc.nextDouble();
		
		System.out.println("enter length");
		length=sc.nextDouble();
		
		System.out.println("enter breadth");
		breadth=sc.nextFloat();
		
		System.out.println("enter side");
		side=sc.nextDouble();
		
		overload o=new overload();
		o.area(base,height);
		o.area(side);
		o.area(length,breadth);
		o.area(radius);
		//System.out.println("area of cirlce is :"+x);
		}
	}
