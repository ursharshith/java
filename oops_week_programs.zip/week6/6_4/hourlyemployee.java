//import 6_3.contractEmployee;
import java.util.*;
public class hourlyemployee extends contractEmployee{
    private double wage;
    private int hours;
    private String desig;
    double getWage(){
        return wage;
    }
    int getHours(){
        return hours;
    }
    void setWage(double w){
        wage=w;
    }
    void setHours(int h){
        hours=h;
    }

    void setDesig(String des){
        desig=des;
    }
    String getDesig(){
        return desig;
    }
    double getSalary(){
        return getWage()*getHours();
    }
    void read(){
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter id: ");
        setEmp_id(sc.next());
        System.out.println("Enter first name: ");
        setFirstname(sc.next());
        System.out.println("Enter last name: ");
        setLastname(sc.next());
        System.out.println("Enter age: ");
        setEmp_age(sc.nextInt());
        System.out.println("Enter salary: ");
        setSalary(sc.nextDouble());
        System.out.println("Enter desig: ");
        setDesig(sc.next());
        sc.nextLine();
        System.out.println("Enter department: ");
        setDept(sc.nextLine());
        sc.nextLine();   
        System.out.println("Enter wage per hour: ");
        setWage(sc.nextDouble());
        System.out.println("Enter num of working hours: ");
        setHours(sc.nextInt()); 
    }
    void print(){
        System.out.println("Hourly Employee Details: ");
        System.out.println("Id: "+getEmp_id());
        System.out.println("Full name: "+getdisplayfullname());
        System.out.println("Age: "+getEmp_age());
        System.out.println("Designation: "+getDesig());
        System.out.println("Department: "+getDept());
        System.out.println("Salary: "+getSalary());
        System.out.println("No.of working hours: "+getHours());
        System.out.println("Total wage: "+getSalary());
        
    }
    
}
