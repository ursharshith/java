
/*
 * Derive sub-classes of ContractEmployee namely HourlyEmployee & WeeklyEmployee with information 
number of hours & wages per hour, number of weeks & wages per week respectively & method 
calculateWages() to calculate their monthly salary. Also override getDesig () method depending on the type of 
contract employee
 */
import java.util.*;
class main_4{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        hourlyemployee h=new hourlyemployee();
        /*h.read();
        h.read1();
        h.print();
        h.print1();*/
        weeklyemployee w=new weeklyemployee();
       /* w.read();
        w.read1();
        w.print();
        w.print1();*/
        do{
            System.out.println("Choose one option: ");
            System.out.println("1.Read hourly employee details\n2.Read weekly employee details\n3.Print hourly employee details\n4.Print weekly employee details\n5.Exit");
            int k=s.nextInt();
            switch(k){
                case 1: System.out.println("Enter hourly employee details: ");
                        h.read();
                        //h.read1();
                        break;
                case 2:System.out.println("Enter weekly employee details: ");
                        w.read();
                      //w.read1();
                      break;
                case 3:h.print();
                       
                       break;
                case 4:w.print();
                        
                        break;

                case 5:
                        System.out.println("Exiting");
                        System.exit(0);
                default:
                        System.out.println("Choose valid option");

            }
        }while(true);
    }
}
