class vehicle{
	private String vehicle_num;
	private int insurance_num;
	private String color;
	int maintanence,consumption;
	float avg;
	
	void setinsurance_num(int insurance_num){
		this.insurance_num=insurance_num;
	}
	int getinsurance_num(){
		return insurance_num;
	}
	void setcolor(String color){
		this.color=color;
	}
	String getcolor(){
		return color;
	}
	void setvehicle_num(String vehicle_num){
		this.vehicle_num=vehicle_num;
		}
	String getvehicle_num(){
		return vehicle_num;
	}
	void setconsumption(int consumption){
		this.consumption=consumption;
	}
	int getconsumption(){
		return consumption;
	}
	void displayconsumption(){
		System.out.println("vehicle consumption: "+getconsumption());
	}
}
class TwoWheeler extends vehicle{
	
	void setmaintanence(int maintanence){
		this.maintanence=maintanence;
		}
	int getmaintanence(){
		return maintanence;
	}
	
	void setavg(float avg){
		this.avg=avg;
		}
	float getavg(){	
		return avg;
	}
	void print(){
	System.out.println("TwoWheeler maintanence: "+getmaintanence());
	System.out.println("TwoWheeler average: "+getavg());
	}
	}
class FourWheeler extends vehicle{	
	void setmaintanence(int maintanence){
		this.maintanence=maintanence;
	}
	int getmaintanence(){
		return maintanence;
	}
	void setavg(float avg){
		this.avg=avg;
	}
	float getavg(){	
		return avg;
	}
	void print(){
	System.out.println("FourWheeler maintanence: "+getmaintanence());
	System.out.println("FourWheeler average: "+getavg());
	}
	}
