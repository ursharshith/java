abstract class polymor{
	double side,length,breadth;
	abstract double area();
	}
class rect extends polymor{
	double area(){
		return length*breadth;
	}
}
class square extends polymor{
	double area(){
		return side*side;
	}
}

