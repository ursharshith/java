import java.util.*;
public class binarysearchMain{
	public static void main(String args[]){
		int n,i,x,l,h,m;
		int a[]=new int[10];
		Scanner s=new Scanner(System.in);
		binarysearch b=new binarysearch();
		System.out.println("enter no.of elemnts");
		n=s.nextInt();
		System.out.println("enter elemnts");
		for(i=0;i<n;i++){
			a[i]=s.nextInt();
		}
		System.out.println("enter search elemnt");
		x=s.nextInt();
		l=0;
		h=n-1;
		b.sort(n,a);
		b.search(n,a,l,h,x);
		}
	}	
		
