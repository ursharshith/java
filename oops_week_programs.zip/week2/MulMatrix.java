public class MulMatrix{
int m1,n1,m2,n2,i,j;

	int a1[][]=new int[20][20];
	int a2[][]=new int[20][20];
	int c[][]=new int[20][20];
	public void mul(){
	if(n1==m2){
		for(i=0;i<m1;i++){
			for(j=0;j<n1;j++){
				c[i][j]=0;
				for(int k=0;k<n2;k++){
				c[i][j]=c[i][j]+(a1[i][k]*a2[k][j]);
			}
		}
	}
		System.out.println("multiplication of matrix:");
		for(i=0;i<m1;i++){
			for(j=0;j<n2;j++){
				System.out.print(c[i][j]+" ");
			}
			System.out.println(" ");
	}
	
	}
	else{
		System.out.println("enter correct rows and columns");
		}
	
	}
}

