import java.util.*;
public class sortMain{
	public static void main(String args[]){
		int n,i;
		int a[]=new int[10];
		Scanner sc=new Scanner(System.in);
		sorting s=new sorting();
		System.out.println("enter no.of elements");
		n=sc.nextInt();
		System.out.println("enter elements");
		for(i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		s.sort(a,n);
		s.print(a,n);
		}
	}
