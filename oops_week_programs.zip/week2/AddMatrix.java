public class AddMatrix{
int m1,n1,m2,n2,i,j;

	int a1[][]=new int[20][20];
		int a2[][]=new int[20][20];
int c[][]=new int[20][20];
	public void add(){
	if(m1==m2 && n1==n2){
		for(i=0;i<m1;i++){
			for(j=0;j<n1;j++){
				c[i][j]=a1[i][j]+a2[i][j];
			}
		}
	}
	//else{
	//	System.out.println("enter square matrix");
	//	}
	System.out.println("addition of matrix:");
	for(i=0;i<m1;i++){
			for(j=0;j<n1;j++){
				System.out.print(c[i][j]+" ");
			}
			System.out.println(" ");
	}
	
	}
}
		
			
		
	
	
	
