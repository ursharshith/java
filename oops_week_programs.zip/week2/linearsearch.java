class linearsearch{
	int i;
	void search(int n,int a[],int x){
		for(i=0;i<n;i++){
			if(a[i]==x){
				System.out.println("elemnt found");
				break;
			}
			
		}
		if(i==n){	
				System.out.println("elemnt not found");
				}
			
		
	}
}
