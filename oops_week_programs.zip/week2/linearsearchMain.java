import java.util.*;
public class linearsearchMain{
	public static void main(String args[]){
		int a[]=new int[10];
		int n,x;
		Scanner sc=new Scanner(System.in);
		linearsearch l=new linearsearch();
		System.out.println("enter no.of elemnts");
		n=sc.nextInt();
		System.out.println("enter elemnts");
		for(int i=0;i<n;i++){
			a[i]=sc.nextInt();
			}
		System.out.println("enter search elemnt");
		x=sc.nextInt();
		l.search(n,a,x);
		}
	}
	
