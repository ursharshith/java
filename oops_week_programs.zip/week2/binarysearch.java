class binarysearch{
int i,j,temp;
	void sort(int n,int a[]){ 
	for(i=0;i<n;i++){
		for(j=0;j<n-i-1;j++){
			if(a[j]>a[j+1]){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	System.out.println("sorted elemts:");
	for(i=0;i<n;i++){
		System.out.println(a[i]);
		}
	}
	
	
	void search(int n,int a[],int l,int h,int x){
		int m;
		m=(l+h)/2;
		if(l<=h){
			if(a[m]==x){
			System.out.println("element found at index: "+m);
			}
			else if(a[m]<x){
				search(n,a,m+1,h,x);
			}
			else{
				search(n,a,l,m-1,x);
			}
		}
		else{
			System.out.println("elemnt not found");
		}
	}
} 
	
			
