import java.util.*;
public class AddMatrixMain{
	public static void main(String args[]){
		int i,j;
		Scanner s=new Scanner(System.in);
		AddMatrix a=new AddMatrix();
		
		System.out.println("enter maxtrix 1 no.of rows");
		a.m1=s.nextInt();
		System.out.println("enter maxtrix 1 no.of columns");
		a.n1=s.nextInt();
		System.out.println("enter maxtrix 2 no.of rows");
		a.m2=s.nextInt();
		System.out.println("enter maxtrix 2 no.of columns");
		a.n2=s.nextInt();
		System.out.println("enter maxtrix 1");
		for(i=0;i<a.m1;i++){
			for(j=0;j<a.n1;j++){
				a.a1[i][j]=s.nextInt();
			}
		}
		System.out.println("enter maxtrix 2");
		for(i=0;i<a.m2;i++){
			for(j=0;j<a.n2;j++){
				a.a2[i][j]=s.nextInt();
			}
		}
		a.add();
	}
}

		
