class CommandArgsInt{
	public static void main(String args[]){
		int sum=0;
		for(String i:args){
			System.out.println(Integer.parseInt(i));
			sum=sum+Integer.parseInt(i);
			}
		System.out.println("sum:"+sum);
		}
	}
