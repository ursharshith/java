class sorting{
	int i,j,swap;
	void sort(int a[],int n){
		for(i=0;i<n;i++){
			for(j=0;j<n-i-1;j++){
				if(a[j]>a[j+1]){
					swap=a[j];
					a[j]=a[j+1];
					a[j+1]=swap;
					}
				}
			}
		}
		void print(int a[],int n){
		System.out.println("elements after sorting:");
			for(i=0;i<n;i++){
				
				System.out.print(a[i]+" ");
				
				}
			}
		}
		
