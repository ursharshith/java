
abstract class shape{
	abstract double getarea();
	abstract double getvolume();
}
class square extends shape{
	double length;
	double getarea(){
	return length*length;
	}
	double getvolume(){
	return 0;
	}
}
class cube extends shape{
	double length;
	double getvolume(){
		return length*length*length;
	}
	double getarea(){
	return 0;
	}
}

class circle extends shape{
	double radius;
	double getarea(){
	 return (2*Math.PI*radius*radius);
	}
	double getvolume(){
	return 0;
	}
}
class sphere extends shape{
	double radius;
	double getvolume(){
	return (4*Math.PI*radius*radius*radius);
	}
	double getarea(){
	return 0;
	}
}

