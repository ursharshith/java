import java.util.Scanner;
class shapeMain{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		square sq=new square();
		System.out.println("enter square length");
		sq.length=sc.nextDouble();
		cube c=new cube();
		System.out.println("enter cube length:");
		c.length=sc.nextDouble();
		sphere sp=new sphere();
		System.out.println("enter sphere radius:");
		sp.radius=sc.nextDouble();
		circle ci=new circle();
		System.out.println("enter circle radius:");
		ci.radius=sc.nextDouble();
		System.out.println("circle area:"+ ci.getarea());
		System.out.println("circle volume"+ci.getvolume());
		System.out.println("square area:"+sq.getarea());
		System.out.println("square volume:"+sq.getvolume());
		System.out.println("sphere area"+sp.getarea());
		System.out.println("sphere vol:"+sp.getvolume());
		System.out.println("cube area"+c.getarea());
	 	System.out.println("cube vol:"+c.getvolume());
	}
}
