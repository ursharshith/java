
import java.util.*;
class main_2_1{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        prod p1=new prod();
        p1.n=s.nextInt();
        prod p[]=new prod[p1.n];
        p1.read(p);
        p1.switches(p);
    }
}
