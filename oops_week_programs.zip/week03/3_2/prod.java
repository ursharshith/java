import java.util.*;
class prod {
    int pid;
    private int product_id;
    private int product_qty;
    private String product_name;
    private double product_price;
    int n;
    int id,q;
    double pr;
    String name;
    double p1=0.0;
    double p2=0.0;
    double p3=0.0;
    double p4=0.0;
    double p5=0.0;
    double price=0.0;
    void setProduct_id(int p){
        product_id=p;
    }
    void setProduct_qty(int p){
        product_qty=p;
    }
    void setProduct_name(String p){
        product_name=p;
    }
    int getProduct_id(){
        return product_id;
    }
    int getProduct_qty(){
        return product_qty;
    }
    String getProduct_name(){
        return product_name;
    }
    void setProduct_price(double pr){
        product_price=pr;
    }
    double getProduct_price(){
        return product_price;
    }
    public prod(){}
    public prod(int p_id,int p_qty,String p_name,double pr){
        setProduct_id(p_id);
        setProduct_qty(p_qty);
        setProduct_name(p_name);
        setProduct_price(pr);
    }
    void read(prod p[]){
        Scanner s=new Scanner(System.in);
        for(int i=0;i<n;i++){
            System.out.println("Enter pid: ");
            id=s.nextInt();
            System.out.println("Enter qty: ");
            q=s.nextInt();
            System.out.println("Enter price: ");
            pr=s.nextDouble();
            System.out.println("Enter pname: ");
            name=s.nextLine();
            s.nextLine();
            p[i]=new prod(id,q,name,pr);
        }
    }
    void switches(prod p[]){
        Scanner s=new Scanner(System.in);
        //double k;
        do{
            System.out.println("Choose a product: ");
            System.out.println("1.Product-1:$"+p[0].product_price+"\n2.Product-2:$"+p[1].product_price+"\n3.Product-3:$"+p[2].product_price+"\n4.Product-4:$"+p[3].product_price+"\n5.Product-5:$"+p[4].product_price+"\n6.Display prices\n7.Exit");

            pid=s.nextInt();
            if(pid<6){
            System.out.println("Enter qty: ");
            q=s.nextInt();
            }
            switch(pid){
                case 1:
                        if(p[0].product_qty>=q){
                        p[0].product_qty=p[0].product_qty-q;
                        p1=p1+q*p[0].product_price;
                        price=price+p1;
                        }
                        else{
                            System.out.println("Not available");
                        }
                        break;
                    case 2:  if(p[1].product_qty>=q){
                        p[1].product_qty=p[1].product_qty-q;
                        p2=p2+q*p[1].product_price;
                        price=price+p2;
                        }
                        else{
                            System.out.println("Not available");
                        }
                        break;
                    case 3:  if(p[2].product_qty>=q){
                        p[2].product_qty=p[2].product_qty-q;
                        p3=p3+q*p[2].product_price;
                        price=price+p3;
                        }
                        else{
                            System.out.println("Not available");
                        }
                        break;
                    case 4: if(p[3].product_qty>=q){
                        p[3].product_qty=p[3].product_qty-q;
                        p4=p4+q*p[3].product_price;
                        price=price+p4;
                        }
                        else{
                            System.out.println("Not available");
                        }
                        break;
                    case 5: if(p[4].product_qty>=q){
                        p[4].product_qty=p[4].product_qty-q;
                        p5=p5+q*p[4].product_price;
                        price=price+p5;
                        }
                        else{
                            System.out.println("Not available");
                        }
                        break;
                    case 6:
                    System.out.println("Individual prices: ");
                    System.out.println("Product-1: "+p1+"\nProduct-2: "+p2+"\nProduct-3: "+p3+"\nProduct-4: "+p4+"\nProduct-5: "+p5);
                    System.out.println("Product-1: "+p[0].product_qty+"\nProduct-2: "+p[1].product_qty+"\nProduct-3: "+p[2].product_qty+"\nProduct-4: "+p[3].product_qty+"\nProduct-5: "+p[4].product_qty);
                    System.out.println("Total price: "+price);
                    break;
                   case 7:
                   System.out.println("Exiting");
                   System.exit(0);
                    default:
                        System.out.println("Choose valid option");
                        break;
                        
            }
        }while(true);
    }
}
