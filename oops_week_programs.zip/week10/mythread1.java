class mythread{
	public void display(){
		int i=1;
		while(true){
		System.out.println("qwerty");
		i++;
		}
	}
}
class threadd extends Thread{
	mythread my;
	threadd(mythread my){
		this.my=my;
	}
	public void run(){
		my.display();
	}
}
class mythread1{
	public static void main(String args[]){
		
		mythread t=new mythread();
		threadd t1=new threadd(t);
		t1.start();
	}
}
