import java.util.Scanner;
class thread1{
	synchronized void display(int n){
		System.out.println("person-"+n+" "+"shown ticket---->entered hall");
	}
}
class t1 extends Thread{
	thread1 t;
	int n;
	t1(thread1 t,int n){
		this.t=t;
		this.n=n;
	}
	
	public void run(){
	int i;
	for(i=1;i<=n;i++){
		t.display(i);
	}
	}
}
class threatre{
	public static void main(String args[]){
		thread1 th=new thread1();
		System.out.println("enter no.of persons");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		t1 tt=new t1(th,n);
		
			tt.start();
		
	}
}

	
		
