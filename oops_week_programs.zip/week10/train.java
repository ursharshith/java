import java.util.Scanner;
class thread1{
	synchronized void display(int n,int b){
		System.out.println(b+" berths are allocated to person "+n);
		System.out.println("person "+n+" can print ticket");
	}
}
class t1 extends Thread{
	thread1 t;
	int n;
	int b;
	int m;
	t1(thread1 t,int n,int m){
		this.t=t;
		this.n=n;
		//this.b=b;
		this.m=m;
	}
	public void run(){
	for(int i=1;i<=m;i++){
	System.out.println("enter no.of berths person "+i+" wants");
	Scanner sc=new Scanner(System.in); 
	int b=sc.nextInt();
	if(b<=n){
		t.display(i,b);
		n=n-b;
	}
	else{
		System.out.println("No berths are available");
	}
	}
	}
}
class train{
	public static void main(String args[]){
		thread1 th=new thread1();
		System.out.println("enter no.of persons");
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		System.out.println("enter total berths");
		int n=sc.nextInt();
		t1 tt=new t1(th,n,m);
			tt.start();
		
	}
}
		
			
		
