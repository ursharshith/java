class mythread extends Thread{
	public void run(){
		while(true){
			System.out.println("red");
			try{
				Thread.sleep(10);
			}
			catch(Exception e){
				System.out.println(e);
			}
			System.out.println("yellow");
			try{
				Thread.sleep(10);
			}
			catch(Exception e){
				System.out.println(e);
			}
			System.out.println("green");
			try{
				Thread.sleep(10);
			}
			catch(Exception e){
				System.out.println(e);
			}			
}
}
}
class traffic{
	public static void main(String args[]){
		mythread t=new mythread();
		t.start();
	}
}
