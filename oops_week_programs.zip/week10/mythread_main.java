class mythread extends Thread{
	public void run(){
		int i=1;
		while(true){
		System.out.println("qwerty");i++;}
	}
}
class mythread_main{
	public static void main(String args[]){
		mythread my=new mythread();
		Thread t=new Thread(my);
		t.start();
	}
}
