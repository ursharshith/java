class uniqueMain{
	public static void main(String args[]){
			unique u=new unique();
			u.uniq();
		}
}
