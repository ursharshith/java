import java.util.*;
class employee{
	int Emp_id,Emp_age, Emp_salary;
	String Emp_name,Emp_gender, Emp_designation, Emp_Address;
	Scanner s=new Scanner(System.in);
	public employee(){}
	 public employee(int id,int age,int salary,String name,String gender,String designation,String address){
	 Emp_name=name;
        Emp_Address=address;
        Emp_age=age;
        Emp_id=id;
       Emp_salary=salary;
        Emp_designation=designation;
       Emp_gender=gender;

    }
	void read(int n,employee e[]){
	for(int i=0;i<n;i++){
		System.out.println("\nenter employee"+(i+1)+" details:");
		System.out.println("employee id\nage\nsalary\ngender\nname\ndesigntion\naddress\n");
		Emp_id=s.nextInt();
		//System.out.println("enter employee age");
		Emp_age=s.nextInt();
		Emp_salary=s.nextInt();
		//System.out.println("enter employee gender");
		Emp_gender=s.next();
		//System.out.println("enter name");
		Emp_name=s.next();
		//System.out.println("Enter designation: ");
		Emp_designation=s.next();
		//System.out.println("Enter address: ");
		Emp_Address=s.next();
		//System.out.println("enter salary");
		//Emp_salary=s.nextInt();
		e[i]=new employee(Emp_id,Emp_age, Emp_salary,Emp_name,Emp_gender, Emp_designation, Emp_Address);
		}
	}
	void display(int n,employee e[])
	{
		for(int i=0;i<n;i++){
			System.out.println(e[i].Emp_id+" "+e[i].Emp_age+" "+e[i].Emp_name+" "+e[i].Emp_gender+" "+e[i].Emp_designation+" "+e[i].Emp_Address+" "+e[i].Emp_salary);
			}
	}
	void search(int n,employee e[],int searchid){
	int i;
		for(i=0;i<n;i++){
			if(e[i].Emp_id==(searchid)){
				System.out.println("Emp_id: "+e[i].Emp_id+"\n"+"Emp_name: "+e[i].Emp_name+"\n"+"Emp_age: "+e[i].Emp_age+"\n"+"Emp_gender: "+e[i].Emp_gender+"\n"+"Emp_address: "+e[i].Emp_Address+"\n"+"Emp_designation: "+e[i].Emp_designation+"\n"+"Emp_Salary: "+e[i].Emp_salary);
				break;
			}
		}
		if(i==n){
			System.out.println("employee id not found!!!");
		}
	}
}
		
	
	
