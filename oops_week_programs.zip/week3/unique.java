import java.util.*;
class unique{
	int dup(int m,int a[],int count)
	{
	for(int i=0;i<=count;i++){
		if(a[i]==m){
			return 0;
		}
	}
	return 1;
	}
	void uniq(){
	int n,i;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter size of the array");
	n=sc.nextInt();
	int a[]=new int[n];
	int count=0,m;
	
	while(count<n){
		System.out.println("enter num:");
		m=sc.nextInt();
			if(dup(m,a,count)==1 && m>=10 && m<=100){
				a[count]=m;
				count++;

			}
			else
			 System.out.println("invalid number");
			
		}
	
	if(count==n){
		System.out.println("unique elemnt set: ");
		for(i=0;i<n;i++){
			System.out.print(a[i]+" ");
		}
	}
}	
}				
