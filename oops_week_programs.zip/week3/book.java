import java.util.*;
class book{
	String bname,bAuthor,cname,cAddress;
	int bcount,cid;
	Scanner s=new Scanner(System.in);
	public book(String bname,String bAuthor,int bcount){
		this.bname=bname;
		this.bAuthor=bAuthor;
		this.bcount=bcount;
	}
	public void read(book b[],int n){
		for(int i=0;i<n;i++){
		System.out.println("enter book name");
		bname=s.next();
		System.out.println("enter book author");
		bAuthor=s.next();
		System.out.println("enter book count");
		bcount=s.nextInt();
		b[i]=new book(bname,bAuthor,bcount);
	}
	}
	public book(){}
	public book(String cname,int cid,String cAddress){	
	this.cid=cid;
	this.cname=cname;
	this.cAddress=cAddress;
	}
	public void read1(book c[],int m){
		for(int i=0;i<m;i++){
			System.out.println("enter customer name");
			cname=s.next();
			System.out.println("enter customer address");
			cAddress=s.next();
			System.out.println("enter customer id");
			cid=s.nextInt();
			c[i]=new book(cname,cid,cAddress);
		}
	}
	void display(book b[],int n,String bkname,int bc){
		int i;
		for(i=0;i<n;i++){
		if(bkname.equalsIgnoreCase(b[i].bname)){
			if(b[i].bcount>=bc){
				System.out.println("book name:"+bkname);
				b[i].bcount=b[i].bcount-bc;
				System.out.println("book count:"+b[i].bcount);
				break;
			}
			else{
				System.out.println("books are unavailable");
				break;
				
			}
		}
		}
		if(i==n){
			System.out.println("Book not found");
		}
	}
}
			
			
	
