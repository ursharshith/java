import java.util.*;
class empMain{
	public static void main(String args[]){
		employee e1=new employee();
		Scanner s=new Scanner(System.in);
		int n;
		System.out.println("enter no.of emplyees");
		n=s.nextInt();
		employee e[]=new employee[n];
		System.out.println("enter any employee id to search");
		int searchid;
		searchid=s.nextInt();
		e1.read(n,e);
		//e1.display(n,e);
		e1.search(n,e,searchid);
		}
	}
		
		
