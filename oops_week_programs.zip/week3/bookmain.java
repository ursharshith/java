import java.util.*;
class bookmain{
	public static void main(String args[]){
		Scanner s=new Scanner(System.in);
		System.out.println("enter no.of books");
		int n=s.nextInt();
		
		
		System.out.println("enter no.of customers");
		int m=s.nextInt();
		
		book bk=new book();
		book b[]=new book[n];
		book c[]=new book[m];
		
		bk.read(b,n);
		bk.read1(c,m);
		System.out.println("enter book name to purchase");
		String bkname=s.next();
		
		System.out.println("enter no.of book required");
		int bc=s.nextInt();
		
		
		//bk.book(c,m);
		//bk.book(bname,bAuthor,bcount);
		//bk.book(cname,cid,cAddress);
		bk.display(b,n,bkname,bc);
	}
}
		
		
